import React, { useState, useEffect } from 'react';
import { Property } from './Dashboard';
import InputField from './InputField';
import Button from './Button';
import HomeIcon from './icons/HomeIcon';
import PriceIcon from './icons/PriceIcon';
import LocationIcon from './icons/LocationIcon';
import ImageIcon from './icons/ImageIcon';
import PhoneIcon from './icons/PhoneIcon';
import CloseIcon from './icons/CloseIcon';
import PlusIcon from './icons/PlusIcon';
import TrashIcon from './icons/TrashIcon';

interface EditPropertyModalProps {
    property: Property;
    onClose: () => void;
    onSave: (property: Property) => void;
}

const EditPropertyModal: React.FC<EditPropertyModalProps> = ({ property, onClose, onSave }) => {
    const [formData, setFormData] = useState<Property>({ ...property });
    const [currentImageUrl, setCurrentImageUrl] = useState('');

    useEffect(() => {
        setFormData({ ...property });
    }, [property]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleAddImageUrl = () => {
        if (currentImageUrl && !formData.imageUrls.includes(currentImageUrl)) {
             try {
                new URL(currentImageUrl); // Validate URL format
                setFormData(prev => ({ ...prev, imageUrls: [...prev.imageUrls, currentImageUrl] }));
                setCurrentImageUrl('');
            } catch (_) {
                alert('Please enter a valid URL.');
            }
        }
    };

    const handleRemoveImageUrl = (urlToRemove: string) => {
        setFormData(prev => ({ ...prev, imageUrls: prev.imageUrls.filter(url => url !== urlToRemove) }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    return (
        <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in-fast"
            onClick={onClose}
        >
             <style>{`
                @keyframes fade-in-fast { from { opacity: 0; } to { opacity: 1; } }
                .animate-fade-in-fast { animation: fade-in-fast 0.2s ease-out forwards; }
            `}</style>
            <div 
                className="bg-gray-800 rounded-2xl shadow-2xl border border-gray-700 w-full max-w-lg p-8 relative"
                onClick={(e) => e.stopPropagation()}
            >
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors">
                    <CloseIcon className="w-6 h-6" />
                </button>
                <h2 className="text-2xl font-semibold text-gray-200 mb-6">Edit Property</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="flex flex-col gap-5">
                        <InputField
                            id="name" name="name" type="text" placeholder="Property Name"
                            value={formData.name} onChange={handleChange} icon={<HomeIcon />} disabled={false} required
                        />
                         <div className="space-y-3">
                            <label htmlFor="edit-property-image-url" className="text-sm font-medium text-gray-300 block">Image URLs</label>
                            <div className="flex gap-2">
                                <InputField
                                    id="edit-property-image-url" name="edit-property-image-url" type="url"
                                    placeholder="Add new image URL"
                                    value={currentImageUrl} onChange={(e) => setCurrentImageUrl(e.target.value)}
                                    icon={<ImageIcon />} disabled={false} required={false}
                                />
                                <button
                                    type="button" onClick={handleAddImageUrl} disabled={!currentImageUrl}
                                    className="p-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-teal-500 disabled:opacity-50 transition-colors"
                                ><PlusIcon className="w-5 h-5"/></button>
                            </div>
                            <div className="space-y-2 max-h-24 overflow-y-auto custom-scrollbar pr-1">
                                {formData.imageUrls.map((url, index) => (
                                    <div key={index} className="flex items-center justify-between bg-gray-700/60 p-2 rounded-md text-sm">
                                        <span className="text-gray-300 truncate w-full pr-2" title={url}>{url}</span>
                                        <button type="button" onClick={() => handleRemoveImageUrl(url)} className="text-gray-400 hover:text-red-400 p-1 rounded-full"><TrashIcon className="w-4 h-4"/></button>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <InputField
                            id="price" name="price" type="text" placeholder="Price"
                            value={formData.price} onChange={handleChange} icon={<PriceIcon />} disabled={false} required
                        />
                        <InputField
                            id="location" name="location" type="text" placeholder="Location"
                            value={formData.location} onChange={handleChange} icon={<LocationIcon />} disabled={false} required
                        />
                         <InputField
                            id="contactPhone" name="contactPhone" type="tel" placeholder="Contact Phone"
                            value={formData.contactPhone} onChange={handleChange} icon={<PhoneIcon />} disabled={false} required
                        />
                    </div>
                    <div className="flex gap-4 pt-2">
                        <button type="button" onClick={onClose} className="w-full py-2.5 px-4 rounded-lg text-sm font-medium bg-gray-600 hover:bg-gray-700 text-white transition-colors">
                            Cancel
                        </button>
                        <Button type="submit" disabled={false}>
                            Save Changes
                        </Button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default EditPropertyModal;
