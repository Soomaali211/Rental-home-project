import React from 'react';
import Logo from './Logo';
import AddPropertyForm from './AddPropertyForm';
import PropertyCard from './PropertyCard';
import EditPropertyModal from './EditPropertyModal';

export interface Property {
    id: number;
    name:string;
    price: string;
    location: string;
    imageUrls: string[];
    contactPhone: string;
    isPublished: boolean;
}

interface DashboardProps {
    onLogout: () => void;
    properties: Property[];
    editingProperty: Property | null;
    setEditingProperty: (property: Property | null) => void;
    onAddProperty: (property: Omit<Property, 'id'>) => void;
    onUpdateProperty: (property: Property) => void;
    onDeleteProperty: (id: number) => void;
    onTogglePublish: (id: number) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
    onLogout, 
    properties, 
    editingProperty, 
    setEditingProperty,
    onAddProperty,
    onUpdateProperty,
    onDeleteProperty,
    onTogglePublish
}) => {
    
    return (
        <>
            <div className="w-full max-w-7xl p-8 space-y-8 bg-gray-800/50 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700 min-h-[80vh]">
                <header className="flex justify-between items-start">
                    <Logo />
                    <button
                        onClick={onLogout}
                        className="mt-4 bg-gray-700 hover:bg-red-600 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-200 flex-shrink-0"
                    >
                        Logout
                    </button>
                </header>
                
                <main className="grid lg:grid-cols-5 gap-12">
                    <section className="lg:col-span-2">
                        <h2 className="text-2xl font-semibold text-gray-200 mb-4 border-b-2 border-teal-500 pb-2">Add New Property</h2>
                        <AddPropertyForm onAddProperty={onAddProperty} />
                    </section>
                    <section className="lg:col-span-3">
                        <h2 className="text-2xl font-semibold text-gray-200 mb-4 border-b-2 border-teal-500 pb-2">Listed Properties</h2>
                        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
                             <style>{`
                                .custom-scrollbar::-webkit-scrollbar {
                                    width: 8px;
                                }
                                .custom-scrollbar::-webkit-scrollbar-track {
                                    background: #2d3748; /* bg-gray-700 */
                                }
                                .custom-scrollbar::-webkit-scrollbar-thumb {
                                    background: #38b2ac; /* bg-teal-500 */
                                    border-radius: 4px;
                                }
                                .custom-scrollbar::-webkit-scrollbar-thumb:hover {
                                    background: #319795; /* bg-teal-600 */
                                }
                            `}</style>
                            {properties.length > 0 ? (
                                properties.map(property => (
                                    <PropertyCard 
                                        key={property.id} 
                                        property={property}
                                        isAdmin={true}
                                        onEdit={setEditingProperty}
                                        onDelete={onDeleteProperty}
                                        onTogglePublish={onTogglePublish}
                                    />
                                ))
                            ) : (
                                <div className="text-center py-10 px-4 bg-gray-800 rounded-lg mt-6">
                                    <p className="text-gray-400">No properties listed yet.</p>
                                    <p className="text-gray-500 text-sm">Use the form on the left to add a new property.</p>
                                </div>
                            )}
                        </div>
                    </section>
                </main>
            </div>
            {editingProperty && (
                <EditPropertyModal 
                    property={editingProperty}
                    onClose={() => setEditingProperty(null)}
                    onSave={onUpdateProperty}
                />
            )}
        </>
    );
};

export default Dashboard;