import React, { useState } from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import PublicView from './components/PublicView';
import { Property } from './components/Dashboard';

// Sample initial data for demonstration
const initialProperties: Property[] = [
    {
        id: 1,
        name: 'Modern Downtown Loft',
        price: '$3,200 / month',
        location: 'New York, NY',
        imageUrls: ['https://images.unsplash.com/photo-1501870190084-627f651583e8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80'],
        contactPhone: '555-0101',
        isPublished: true,
    },
    {
        id: 2,
        name: 'Sunny Beachside Bungalow',
        price: '$2,500 / month',
        location: 'Miami, FL',
        imageUrls: ['https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1674&q=80'],
        contactPhone: '555-0102',
        isPublished: true,
    },
    {
        id: 3,
        name: 'Cozy Cabin in the Woods',
        price: '$1,800 / month',
        location: 'Aspen, CO',
        imageUrls: ['https://images.unsplash.com/photo-1554995207-c18c203602cb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80'],
        contactPhone: '555-0103',
        isPublished: false,
    }
];


function App() {
  const [properties, setProperties] = useState<Property[]>(initialProperties);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [view, setView] = useState<'public' | 'login' | 'dashboard'>('public');

  const handleGoToLogin = () => setView('login');
  const handleLoginSuccess = () => setView('dashboard');
  const handleLogout = () => setView('public');
  const handleCancelLogin = () => setView('public');

  const handleAddProperty = (propertyData: Omit<Property, 'id'>) => {
    const newProperty = { ...propertyData, id: Date.now() };
    setProperties(prev => [newProperty, ...prev]);
    setEditingProperty(newProperty); // Open edit modal for the new property
  };

  const handleUpdateProperty = (updatedProperty: Property) => {
    setProperties(prev => prev.map(p => p.id === updatedProperty.id ? updatedProperty : p));
    setEditingProperty(null);
  };

  const handleDeleteProperty = (propertyId: number) => {
    if (window.confirm('Are you sure you want to delete this property?')) {
        setProperties(prev => prev.filter(p => p.id !== propertyId));
    }
  };
  
  const handleTogglePublish = (propertyId: number) => {
    setProperties(prev => 
        prev.map(p => p.id === propertyId ? { ...p, isPublished: !p.isPublished } : p)
    );
  };

  const renderContent = () => {
    switch(view) {
        case 'login':
            return <Login onLoginSuccess={handleLoginSuccess} onCancel={handleCancelLogin} />;
        case 'dashboard':
            return <Dashboard 
                        onLogout={handleLogout} 
                        properties={properties}
                        editingProperty={editingProperty}
                        setEditingProperty={setEditingProperty}
                        onAddProperty={handleAddProperty}
                        onUpdateProperty={handleUpdateProperty}
                        onDeleteProperty={handleDeleteProperty}
                        onTogglePublish={handleTogglePublish}
                   />;
        case 'public':
        default:
            return <PublicView properties={properties} onGoToLogin={handleGoToLogin} />;
    }
  }

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex items-center justify-center p-4 selection:bg-teal-500 selection:text-white">
      {renderContent()}
    </div>
  );
}

export default App;