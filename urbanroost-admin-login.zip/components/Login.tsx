import React, { useState, useCallback } from 'react';
import Logo from './Logo';
import InputField from './InputField';
import Button from './Button';
import UserIcon from './icons/UserIcon';
import LockIcon from './icons/LockIcon';
import SpinnerIcon from './icons/SpinnerIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon';

interface LoginProps {
    onLoginSuccess: () => void;
    onCancel: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess, onCancel }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleLogin = useCallback((e: React.FormEvent) => {
        e.preventDefault();
        if (isLoading) return;

        setError('');
        setIsLoading(true);

        // Simulate API call
        setTimeout(() => {
            if (username === 'admin' && password === 'password123') {
                onLoginSuccess();
            } else {
                setError('Invalid username or password.');
            }
            setIsLoading(false);
        }, 1500);
    }, [username, password, isLoading, onLoginSuccess]);

    return (
        <div className="w-full max-w-md p-8 space-y-8 bg-gray-800/50 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700 relative">
            <button 
                onClick={onCancel} 
                className="absolute top-4 left-4 text-gray-400 hover:text-white transition-colors p-2 rounded-full bg-gray-700/50 hover:bg-gray-700"
                aria-label="Back to site"
            >
                <ArrowLeftIcon className="w-5 h-5" />
            </button>
            <Logo />
            <form className="mt-8 space-y-6" onSubmit={handleLogin}>
                <div className="rounded-md -space-y-px flex flex-col gap-5">
                    <InputField
                        id="username"
                        name="username"
                        type="text"
                        placeholder="Username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        icon={<UserIcon />}
                        disabled={isLoading}
                    />
                    <InputField
                        id="password"
                        name="password"
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        icon={<LockIcon />}
                        disabled={isLoading}
                    />
                </div>

                <div className="h-6 text-center">
                    {error && (
                        <p className="text-sm text-red-400">{error}</p>
                    )}
                </div>

                <div>
                    <Button type="submit" disabled={isLoading || !username || !password}>
                        {isLoading ? (
                            <>
                                <SpinnerIcon />
                                <span>Authenticating...</span>
                            </>
                        ) : (
                            'Sign In'
                        )}
                    </Button>
                </div>
            </form>
        </div>
    );
};

export default Login;