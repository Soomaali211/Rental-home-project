import React from 'react';
import { Property } from './Dashboard';
import PropertyCard from './PropertyCard';
import Logo from './Logo';

interface PublicViewProps {
    properties: Property[];
    onGoToLogin: () => void;
}

const PublicView: React.FC<PublicViewProps> = ({ properties, onGoToLogin }) => {
    const publishedProperties = properties.filter(p => p.isPublished);

    return (
        <div className="w-full max-w-7xl p-8 space-y-8 bg-gray-800/50 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700 min-h-[80vh]">
            <header className="flex justify-between items-start">
                <Logo />
                <button
                    onClick={onGoToLogin}
                    className="mt-4 bg-teal-600 hover:bg-teal-700 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-200"
                >
                    Admin Login
                </button>
            </header>
            
            <main>
                <h2 className="text-3xl font-bold text-gray-200 mb-6 text-center">Available Properties</h2>
                 {publishedProperties.length > 0 ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {publishedProperties.map(property => (
                            <PropertyCard 
                                key={property.id} 
                                property={property}
                                isAdmin={false}
                            />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20 px-4 bg-gray-800 rounded-lg mt-6">
                        <p className="text-gray-400 text-lg">No properties are available at the moment.</p>
                        <p className="text-gray-500 text-sm">Please check back later.</p>
                    </div>
                )}
            </main>
        </div>
    );
};

export default PublicView;
