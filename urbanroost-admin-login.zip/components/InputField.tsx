import React from 'react';

interface InputFieldProps {
  id: string;
  name: string;
  type: string;
  placeholder: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  icon: React.ReactNode;
  disabled: boolean;
  required?: boolean;
}

const InputField: React.FC<InputFieldProps> = ({ id, name, type, placeholder, value, onChange, icon, disabled, required = true }) => {
  return (
    <div className="relative">
      <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
        {icon}
      </span>
      <input
        id={id}
        name={name}
        type={type}
        required={required}
        className="w-full pl-10 pr-4 py-2.5 border rounded-lg bg-gray-700/50 border-gray-600 text-gray-200 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors duration-200 disabled:opacity-50"
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        disabled={disabled}
      />
    </div>
  );
};

export default InputField;
