import React from 'react';
import HomeIcon from './icons/HomeIcon';
import PriceIcon from './icons/PriceIcon';
import LocationIcon from './icons/LocationIcon';
import PhoneIcon from './icons/PhoneIcon';
import EditIcon from './icons/EditIcon';
import TrashIcon from './icons/TrashIcon';
import ToggleSwitch from './ToggleSwitch';
import { Property } from './Dashboard';

interface PropertyCardProps {
    property: Property;
    isAdmin: boolean;
    onEdit?: (property: Property) => void;
    onDelete?: (id: number) => void;
    onTogglePublish?: (id: number) => void;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property, isAdmin, onEdit, onDelete, onTogglePublish }) => {
    return (
        <div className="bg-gray-800 rounded-lg border border-gray-700 shadow-md hover:shadow-lg hover:border-teal-500 transition-all duration-300 animate-fade-in overflow-hidden">
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(-10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in { animation: fade-in 0.3s ease-out forwards; }
            `}</style>
            <div className="relative">
                 <img 
                    src={property.imageUrls?.[0] || 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80'} 
                    alt={property.name} 
                    className="w-full h-48 object-cover"
                />
                {isAdmin && onEdit && onDelete && onTogglePublish && (
                    <div className="absolute top-2 right-2 flex gap-2">
                        <button onClick={() => onEdit(property)} className="p-2 rounded-full bg-gray-900/50 hover:bg-teal-500 text-white transition-colors" aria-label="Edit Property">
                            <EditIcon className="w-5 h-5" />
                        </button>
                        <button onClick={() => onDelete(property.id)} className="p-2 rounded-full bg-gray-900/50 hover:bg-red-500 text-white transition-colors" aria-label="Delete Property">
                            <TrashIcon className="w-5 h-5" />
                        </button>
                    </div>
                )}
            </div>
            <div className="p-4">
                <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center">
                        <div className="p-2 bg-teal-500/20 rounded-full mr-3">
                            <HomeIcon className="w-5 h-5 text-teal-400" />
                        </div>
                        <h3 className="font-bold text-lg text-gray-100 truncate">{property.name}</h3>
                    </div>
                    {isAdmin && (
                        <div className="flex items-center gap-2">
                            <span className={`text-xs font-semibold ${property.isPublished ? 'text-green-400' : 'text-gray-400'}`}>
                                {property.isPublished ? 'Published' : 'Draft'}
                            </span>
                            <ToggleSwitch
                                checked={property.isPublished}
                                onChange={() => onTogglePublish!(property.id)}
                            />
                        </div>
                    )}
                </div>

                <div className="space-y-2 text-sm text-gray-300 pl-4 border-l-2 border-gray-700 ml-5">
                     <div className="flex items-center gap-2">
                        <PriceIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />
                        <span>{property.price}</span>
                    </div>
                     <div className="flex items-center gap-2">
                        <LocationIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />
                        <span>{property.location}</span>
                    </div>
                     <div className="flex items-center gap-2">
                        <PhoneIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />
                        <span>{property.contactPhone}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PropertyCard;