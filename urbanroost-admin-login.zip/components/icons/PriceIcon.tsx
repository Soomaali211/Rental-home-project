import React from 'react';

const PriceIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-5 w-5 text-gray-400"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
        {...props}
    >
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8V6m0 12v-2" />
        <path d="M8.401 7.793A7.965 7.965 0 0112 6c3.314 0 6 2.686 6 6s-2.686 6-6 6a7.965 7.965 0 01-3.599-1.793" />
    </svg>
);

export default PriceIcon;