
import React from 'react';

interface ButtonProps {
  type: 'submit' | 'button';
  disabled: boolean;
  children: React.ReactNode;
}

const Button: React.FC<ButtonProps> = ({ type, disabled, children }) => {
  return (
    <button
      type={type}
      disabled={disabled}
      className="w-full flex justify-center items-center py-2.5 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-teal-500 disabled:bg-teal-500/40 disabled:cursor-not-allowed transition-all duration-200"
    >
      {children}
    </button>
  );
};

export default Button;
