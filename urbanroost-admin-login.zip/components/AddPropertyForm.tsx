import React, { useState, FormEvent } from 'react';
import InputField from './InputField';
import Button from './Button';
import HomeIcon from './icons/HomeIcon';
import PriceIcon from './icons/PriceIcon';
import LocationIcon from './icons/LocationIcon';
import SpinnerIcon from './icons/SpinnerIcon';
import ImageIcon from './icons/ImageIcon';
import PhoneIcon from './icons/PhoneIcon';
import PlusIcon from './icons/PlusIcon';
import TrashIcon from './icons/TrashIcon';
import { Property } from './Dashboard';

interface AddPropertyFormProps {
    onAddProperty: (property: Omit<Property, 'id'>) => void;
}

const AddPropertyForm: React.FC<AddPropertyFormProps> = ({ onAddProperty }) => {
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [location, setLocation] = useState('');
    const [imageUrls, setImageUrls] = useState<string[]>([]);
    const [currentImageUrl, setCurrentImageUrl] = useState('');
    const [contactPhone, setContactPhone] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleAddImageUrl = () => {
        if (currentImageUrl && !imageUrls.includes(currentImageUrl)) {
            try {
                new URL(currentImageUrl); // Validate URL format
                setImageUrls([...imageUrls, currentImageUrl]);
                setCurrentImageUrl('');
            } catch (_) {
                alert('Please enter a valid URL.');
            }
        }
    };

    const handleRemoveImageUrl = (urlToRemove: string) => {
        setImageUrls(imageUrls.filter(url => url !== urlToRemove));
    };

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        if (!name || !price || !location || !contactPhone || isLoading) return;
        
        setIsLoading(true);
        // Simulate async operation
        setTimeout(() => {
            onAddProperty({ name, price, location, imageUrls, contactPhone, isPublished: false });
            setName('');
            setPrice('');
            setLocation('');
            setImageUrls([]);
            setCurrentImageUrl('');
            setContactPhone('');
            setIsLoading(false);
        }, 500);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6 bg-gray-800 p-6 rounded-lg">
            <div className="flex flex-col gap-5">
                <InputField
                    id="property-name" name="property-name" type="text"
                    placeholder="Property Name (e.g., Cozy Apartment)"
                    value={name} onChange={(e) => setName(e.target.value)}
                    icon={<HomeIcon />} disabled={isLoading} required
                />
                
                <div className="space-y-3">
                     <label htmlFor="property-image-url" className="text-sm font-medium text-gray-300 block">Image URLs</label>
                    <div className="flex gap-2">
                        <InputField
                            id="property-image-url" name="property-image-url" type="url"
                            placeholder="https://example.com/image.png"
                            value={currentImageUrl} onChange={(e) => setCurrentImageUrl(e.target.value)}
                            icon={<ImageIcon />} disabled={isLoading} required={false}
                        />
                        <button
                            type="button"
                            onClick={handleAddImageUrl}
                            disabled={!currentImageUrl || isLoading}
                            className="p-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-teal-500 disabled:opacity-50 transition-colors"
                        >
                            <PlusIcon className="w-5 h-5"/>
                        </button>
                    </div>
                    <div className="space-y-2">
                        {imageUrls.map((url, index) => (
                            <div key={index} className="flex items-center justify-between bg-gray-700/60 p-2 rounded-md text-sm animate-fade-in">
                                <span className="text-gray-300 truncate w-full pr-2" title={url}>{url}</span>
                                <button type="button" onClick={() => handleRemoveImageUrl(url)} className="text-gray-400 hover:text-red-400 p-1 rounded-full"><TrashIcon className="w-4 h-4"/></button>
                            </div>
                        ))}
                    </div>
                </div>

                <InputField
                    id="property-price" name="property-price" type="text"
                    placeholder="Price (e.g., $2,500 / month)"
                    value={price} onChange={(e) => setPrice(e.target.value)}
                    icon={<PriceIcon />} disabled={isLoading} required
                />
                <InputField
                    id="property-location" name="property-location" type="text"
                    placeholder="Location (e.g., San Francisco, CA)"
                    value={location} onChange={(e) => setLocation(e.target.value)}
                    icon={<LocationIcon />} disabled={isLoading} required
                />
                 <InputField
                    id="property-contact" name="property-contact" type="tel"
                    placeholder="Contact Phone (e.g., 555-123-4567)"
                    value={contactPhone} onChange={(e) => setContactPhone(e.target.value)}
                    icon={<PhoneIcon />} disabled={isLoading} required
                />
            </div>
            <Button type="submit" disabled={isLoading || !name || !price || !location || !contactPhone}>
                {isLoading ? ( <> <SpinnerIcon /> <span>Adding...</span> </> ) : ( 'Add Property' )}
            </Button>
        </form>
    );
};

export default AddPropertyForm;